<?php
//error_reporting(E_ALL);
//ini_set('display_errors', true);
require_once('tcpdf/config/lang/eng.php');
require_once('tcpdf/tcpdf.php');

// Extend the TCPDF class to create custom Header and Footer
class RWTCPDF extends TCPDF {
  // properties
  var $reportTitle;
  var $includeHeader; 
  var $reportTemplate;
  var $physicianInfo;
  var $transcriptPeriod;
  var $pluginRoot;

  public function Header() {
    if ($this->includeHeader) {
      if ($this->reportTemplate == 'transcript') {
        $this->Image($this->pluginRoot."/tcpdf/images/bch_logo.jpg", 13, 10, 65);
    	  $this->SetY(10);
      	$this->SetFont('dejavusans', '', 8);
  			$this->SetTextColor(0, 0, 0);
        $html = "<p style='text-align:right'>".$this->physicianInfo["name"]."<br/>".$this->physicianInfo["address"]."<br/>".$this->physicianInfo["city"].",".$this->physicianInfo["state"]." ".$this->physicianInfo["zipcode"]."<br/>".$this->physicianInfo["country"]."</p>";
        $this->writeHTMLCell(0, 0, 0, 13, $html, 0, 1, 0, true, 'R', 'B');
        $html = "<table cellpadding=\"2\" bgcolor=\"#808080\" style=\"color:#ffffff;\">";
        $html.= "<tr><td align=\"left\">Transcript Period: ".$this->transcriptPeriod["start_date"]." to ".$this->transcriptPeriod["end_date"]."</td><td align=\"right\">Created on: ".date("m-d-Y")."</td></tr></table>";
        $this->writeHTMLCell(0, 0, 15, 30, $html, 0, 1, 0, true, 'R', 'B');
      }
    }
  }
    
  // Page footer
  public function Footer() {
    if ($this->includeHeader) {
      if ($this->reportTemplate == 'transcript') {
      	$footer_text = "In support of improving patient care, Boston Children's Hospital is jointly accredited by the Accreditation Council for Continuing Medical Education (ACCME), the Accreditation Council for Pharmacy Education (ACPE), and the American Nurses Credentialing Center (ANCC), to provide continuing education for the healthcare team.";
        // Set font
        $this->SetTextColor(0, 0, 0);
        $this->SetFont('dejavusanscondensed', '', 8);
        $footer_html = "<table width=\"100%\"><tr><td style=\"font-size:6pt;\" width=\"60%\" align=\"left\">".$footer_text."</td><td width=\"40%\" align=\"right\">".'Page '.$this->getAliasNumPage().' of '.$this->getAliasNbPages()."</td></tr></table>";
        $this->writeHTMLCell(0, 0, 15, 262, $footer_html, 0, 1, 0, true, 'R', 'B');
      }
    }
  }
}

function createPDF($htmltable, $reportTitle, $outputDest, $reportTemplate, $physicianInfo, $transcriptPeriod, $pluginRoot) {
	global $l;

  $pdf = new RWTCPDF("P", "mm", "LETTER", true, 'UTF-8', false);
  $pdf->includeHeader = true;		

	$pdf->reportTitle = $reportTitle;
	$pdf->reportTemplate = $reportTemplate;
	$pdf->physicianInfo = $physicianInfo;
	$pdf->transcriptPeriod = $transcriptPeriod;
  $pdf->pluginRoot = $pluginRoot;

	// set document information
	$pdf->SetCreator("Boston Children's Hospital Department of Education");
	$pdf->SetAuthor("Boston Children's Hospital Department of Education");
	$subject = "Transcript for ".$physicianInfo["name"]." period ".$transcriptPeriod["start_date"]." to ".$transcriptPeriod["end_date"];
	$pdf->SetTitle($subject);
	$pdf->SetSubject($subject);
	$pdf->SetKeywords('');

	// set default monospaced font
	$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);

	//set margins
	$left_margin = 15;
	$right_margin = 20;
	$top_margin = 40;
	$pdf->SetMargins($left_margin, $top_margin, $right_margin);

	//set auto page breaks
	$pdf->SetAutoPageBreak(TRUE, 20);

	//set image scale factor
	$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO); 

	//set some language-dependent strings
	$pdf->setLanguageArray($l); 

	// ---------------------------------------------------------

	// add a page
	$pdf->AddPage();

	// set font
  $pdf->SetTextColor(0, 0, 0);
	$pdf->SetFont("helvetica", '', 10);

	// output the HTML content
	$pdf->writeHTML($htmltable, true, 0, true, 0);

	// ---------------------------------------------------------

	//Close and output PDF document
	if ($outputDest == 'browser') {
		$pdf->Output('example_001.pdf', 'I');
		return true;
	}
	if ($outputDest == 'string') {
		$pdfString = $pdf->Output('example_001.pdf', 'S');
		return $pdfString;
	}
	if ($outputDest == 'file') {
		// generate a unique filename
		$pdf->Output('example_001.pdf', 'F');
		return $fileName;
	}
	if ($outputDest == 'download') {
		$pdf->Output('example_001.pdf', 'D');
		return true;
	}
}
?>