<?php
//error_reporting(E_ALL);
//ini_set('display_errors', true);

include_once('BchCmeCreditManager_LifeCycle.php');

class BchCmeCreditManager_Plugin extends BchCmeCreditManager_LifeCycle {

  /**
    * See: http://plugin.michael-simpson.com/?page_id=31
    * @return array of option meta data.
    */
  public function getOptionMetaData() {
    // http://plugin.michael-simpson.com/?page_id=31
    return array(
      //'_version' => array('Installed Version'), // Leave this one commented-out. Uncomment to test upgrades.
      'bch_cm_CreditTypes' => array(__('Credit Types', 'bch_creditmanager'), 'user_array')
    );
  }

//    protected function getOptionValueI18nString($optionValue) {
//        $i18nValue = parent::getOptionValueI18nString($optionValue);
//        return $i18nValue;
//    }

    protected function initOptions() {
        $options = $this->getOptionMetaData();
        if (!empty($options)) {
            foreach ($options as $key => $arr) {
                if (is_array($arr) && count($arr > 1)) {
                    $this->addOption($key, $arr[1]);
                }
            }
        }
    }

    public function getPluginDisplayName() {
        return 'BCH CME Credit Manager';
    }

    protected function getMainPluginFileName() {
        return 'bch-cme-credit-manager.php';
    }

    /**
     * See: http://plugin.michael-simpson.com/?page_id=101
     * Called by install() to create any database tables if needed.
     * Best Practice:
     * (1) Prefix all table names with $wpdb->prefix
     * (2) make table names lower case only
     * @return void
     */
    protected function installDatabaseTables() {
        //        global $wpdb;
        //        $tableName = $this->prefixTableName('mytable');
        //        $wpdb->query("CREATE TABLE IF NOT EXISTS `$tableName` (
        //            `id` INTEGER NOT NULL");
    }

    /**
     * See: http://plugin.michael-simpson.com/?page_id=101
     * Drop plugin-created tables on uninstall.
     * @return void
     */
    protected function unInstallDatabaseTables() {
        //        global $wpdb;
        //        $tableName = $this->prefixTableName('mytable');
        //        $wpdb->query("DROP TABLE IF EXISTS `$tableName`");
    }


    /**
     * Perform actions when upgrading from version X to version Y
     * See: http://plugin.michael-simpson.com/?page_id=35
     * @return void
     */
    public function upgrade() {
    }

    /**
     * Add metadata box to learndash courses to capture the CME credit parameters
     * author: Stephan Fopeano
     * @return void
    */
    function certificateOptions($post) {
    	// sfwd-courses is the post type for courses, which is where we want to add the meta box
	    add_meta_box(
		    'bch_cm_cme_options',
		    esc_html__( 'CME Course Credits', 'bch_creditmanager' ),
		    array(&$this,'cme_metabox'),
		    'sfwd-courses',
		    'advanced',
		    'high'
	    );
    }

    /**
     * Save the certificate options from the metabox that captures the credits available for this course
     * author: Stephan Fopeano
     * @return void
    */
    function saveCertificateOptions($post_id) {
      // verify if this is an auto save routine.
      // If it is our form has not been submitted, so we dont want to do anything
      if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
        return;
      }

      // verify this came from the our screen and with proper authorization,
      // because save_post can be triggered at other times
      if (!isset($_POST['bch_cm_cme_options_nonce']) || !wp_verify_nonce($_POST['bch_cm_cme_options_nonce'], plugin_basename( __FILE__ ))) {
        return;
      }

      if ('sfwd-courses' != $_POST['post_type']) {
        return;
      }

      // Check permissions
      if ( ! current_user_can( 'edit_post', $post_id ) ) {
        return;
      }

      $existing_credit_types = get_post_meta($post_id, 'bch_cm_cme_credit_type', false);
      $cme_options_array = $_POST['cme_options'];
      $credit_types_only = array();
      foreach($cme_options_array as $cme_option) {
      	$credit_types_only[] = $cme_option["credit_type"];
      	if (array_search($cme_option["credit_type"],$existing_credit_types) === false) {
          add_post_meta($post_id, 'bch_cm_cme_credit_type', $cme_option["credit_type"], false);
        }
        update_post_meta($post_id, 'bch_cm_cme_credit_hours_'.$cme_option["credit_type"], $cme_option["credit_hours"]);
      }
      // delete any records that were removed by the user
      foreach($existing_credit_types as $existing_credit_type) {
      	if (array_search($existing_credit_type, $credit_types_only) === false) {
          delete_post_meta($post_id, 'bch_cm_cme_credit_type', $existing_credit_type);
          delete_post_meta($post_id, 'bch_cm_cme_credit_hours_'.$existing_credit_type);
        }
      }

      return true;
    }
    
    function cme_metabox($certificate) {
      // returns all the matching post_meta fields for this key, which returns the ID of the credit type
	    $cme_options_post_meta = get_post_meta( $certificate->ID, 'bch_cm_cme_credit_type', false);

      // js script file for handling the management of the rows
      wp_enqueue_script('course-meta-box', plugins_url('/js/course-meta-box.js', __FILE__));

	    wp_nonce_field( plugin_basename( __FILE__ ), 'bch_cm_cme_options_nonce' );

      $cme_options_array = array();
      $cme_credit_types = array();
      foreach (get_option("BchCmeCreditManager_Plugin_bch_cm_CreditTypes") as $index => $option_array) {
        $cme_credit_types[$option_array[0]] = $option_array[2];
        if (array_search($option_array[0],$cme_options_post_meta) !== false) {
        	$cme_options_array[$option_array[0]]["credit_type"] = $option_array[0];
        	$cme_options_array[$option_array[0]]["credit_hours"] = get_post_meta( $certificate->ID, 'bch_cm_cme_credit_hours_'.$option_array[0], true);
        }
      }
 
      // insert a hidden field that contains the list of credit type options for the select list. This is used by
      // the javascript function that adds a new option to the table
      //$options_html = "<input type=\"hidden\" id=\"bch_cm_credit_type_options\" value='{\"6\":\"CPE Pharmacy Technician\",\"1\":\"Physician CME\"}'/>";
      $options_html = "<script>var bch_cm_credit_type_options = '".json_encode($cme_credit_types, JSON_HEX_QUOT)."';</script>";

      $options_html.= "<table id=\"bch_cm_credit_table\">";
      $options_html.= "<thead><tr><th>Credit Type</th><th>Credit Hours</th><th>Delete</th></tr></thead><tbody>";
      
      $counter = 0;
      foreach($cme_options_array as $index => $cme) {
        $options_html.= "<tr id=\"cme_options_row_".$counter."\"><td>";
        $options_html.= "<select id=\"credit_type_".$counter."\" name=\"cme_options[".$counter."][credit_type]\">";
          $options_html.= "<option value=\"\">Please select</option>";
          foreach($cme_credit_types as $key => $label ) {
            $options_html.= "<option ";
            if ($key == $cme["credit_type"]) $options_html.= "selected=\"selected\"";
            $options_html.= " value=\"".$key."\">".$label."</option>";
          }
        $options_html.= "</select>";
        $options_html.= "</td><td>";
        $options_html.= "<input type=\"text\" name=\"cme_options[".$counter."][credit_hours]\" id=\"credit_hours_".$counter."\" value=\"";
        if ($cme["credit_hours"] && $cme["credit_hours"] != "") $options_html.= $cme["credit_hours"];
        $options_html.= "\"/>";
        $options_html.= "</td>";
        $options_html.= "<td><a href=\"javascript:void(0);\" class=\"bch-cm-remove-row\" id=\"bch_cm_remove_row_".$counter."\">Remove</td></tr>";
        $counter++;
      }
      $options_html.= "</tbody></table>";
      $options_html.= "<p><a id=\"bch_cm_add_rows\" href=\"javascript:void(0);\">Add a new credit type</a></a>";
    	echo $options_html;
    }

    /**
     * Add metadata boxe to learndash courses to capture the CME credit parameters
     * author: Stephan Fopeano
     * @return void
    */
    function certificateContent($cert_content, $post_id) {

      $cert_content.= "<p>Post ID = ".$post_id."</p>";
      return $cert_content;
    }

    /**
     * Create a user interface for starting a course, including the ability to specify
     * the desired credits
     * author: Stephan Fopeano
     * @return void
    */
    function creditSelector($course_id, $user_id = null) {
    	global $current_user;
      get_currentuserinfo();

      // js script file for handling the form submission
      wp_enqueue_script('enrollment-form', plugins_url('/js/enrollment_form.js', __FILE__));
      wp_enqueue_style("enrollment-css", plugins_url('/css/enrollment_form.css', __FILE__));
      
      wp_localize_script('enrollment-form', 'enrollment_form_object', array(
        'ajax_url' => admin_url('admin-ajax.php'),
        'ajax_nonce' => wp_create_nonce('enrollment-form-nonce'),
        'loading_graphic' => plugins_url('/images/loading.gif', __FILE__)
      ));

      // get the list of credit types with their options from the plugin options
      $credit_type_options = get_option("BchCmeCreditManager_Plugin_bch_cm_CreditTypes");
      $credit_type_array = array();
      $credit_desc_array = array();
      foreach($credit_type_options as $index => $ct) {
    	  // 0 is the record key, 3 = the board label
        $credit_type_array[$ct[0]] = $ct[3];
        $credit_desc_array[$ct[0]] = $ct[2];
      }
	    // get the credit types assigned to this course
	    $cme_options_array = get_post_meta($course_id, 'bch_cm_cme_credit_type', false);

      $enroll_html = "<input type=\"hidden\" id=\"bch_cme_credit_mananager_current_user\" value=\"".$current_user->ID."\">";
	    $enroll_html.= "<div id=\"bch_cme_credit_mananager_enrollment_div\"><h3>Course Credit</h3>";

      $post = get_post($course_id);

      if ($post->post_type !== "sfwd-courses" ) {
	      // don't display anything?
	      echo "Post type is not a course";
	      return;	
	    }

      if (!sfwd_lms_has_access($post->ID, $current_user->ID) || $current_user->ID == "") {
      	if (count($cme_options_array) == 0) {
      	  $enroll_html.= "<p>There are no credits available for this course</p>";
      	  $enroll_html.= "</div>";
	        echo $enroll_html;
	        return;	
      	} else if (count($cme_options_array) == 1) {
      	  $enroll_html.= "<p>The following credit is available for this course:</p>";
      	} else {
      	  $enroll_html.= "<p>The following credits are available for this course:</p>";      		
      	}
      	$enroll_html.= "<table>";
      	foreach ($cme_options_array as $cme_option) {
          $enroll_html.= "<tr>";
          $enroll_html.= "<td>".$credit_desc_array[$cme_option]."</td>";
          $enroll_html.= "<td>".get_post_meta($course_id, "bch_cm_cme_credit_hours_".$cme_option, true)." hours</td>";
          $enroll_html.= "</tr>";
      	}
        $enroll_html.= "</table>";
        $enroll_html.= "</div>";
        echo $enroll_html;
			  return;
		  }

      // get the user's current selections for this course
      $user_selections_array = get_user_meta($current_user->ID, "bch_cm_cme_selections_".$course_id, false);
      // create an array with the credit type id as the index of the array
      $user_selections_indexed = array();
      foreach($user_selections_array[0] as $selection) {
      	$user_selections_indexed[$selection["credit_type"]] = array(
      	  "board_name" => $selection["board_name"],
      	  "board_id" => $selection["board_id"],
      	  "dob" => $selection["dob"]
      	);
      }
      
	    $enroll_html.= "<div id=\"bch_cme_credit_mananager_form_div\">";
      if (!$cme_options_array || count($cme_options_array) == 0) {
    	  $enroll_html.= "<p style=\"clear:both;padding-top:8px;\">CME Credit is not available for this course</p>";
      } else {
	      $enroll_html.= "<p style=\"clear:both;padding-top:8px;\">Please select the credit types you wish to apply to this course:</p>";
        $enroll_html.= "<form id=\"bch_cme_credit_mananager_enrollment_form\" method=\"POST\"/>";
        $enroll_html.= "<input type=\"hidden\" id=\"bch_cme_course_id\" name=\"course_id\" value=\"".$course_id."\"/>";
        $enroll_html.= "<table>";
        $counter = 0;
        foreach($cme_options_array as $index => $cme) {
          $enroll_html.= "<tr><td style=\"width:30px;\">";
          $enroll_html.= "<input type=\"checkbox\" name=\"credit_type[".$counter."]\" id=\"credit_type_".$counter."\" value=\"".$cme["credit_type"]."\"";
          if (array_key_exists($cme["credit_type"],$user_selections_indexed) !== false) $enroll_html.= " checked=\"checked\"";
          $enroll_html.= "/></td>";
          $enroll_html.= "<td>".$cme["credit_hours"]."&nbsp;hrs</td>";
          $enroll_html.= "<td>".$credit_desc_array[$cme["credit_type"]]."&nbsp;</td><td>&nbsp;</td>";
          if (array_key_exists($cme["credit_type"],$credit_type_array)) {
            if ($credit_type_array[$cme["credit_type"]] != "") {
              $enroll_html.= "<td>".$credit_type_array[$cme["credit_type"]]." Board ID#: <input style=\"width:150px;\" type=\"text\" name=\"board_id[".$counter."]\" id=\"board_id_".$counter."\" value=\"";
          	  // get the user's saved id for this board if there is one
          	  $saved_board_id = get_user_meta($current_user->ID, "bch_cm_board_id_".$credit_type_array[$cme["credit_type"]], true);
              if (array_key_exists($cme["credit_type"],$user_selections_indexed) !== false) {
              	if ($user_selections_indexed[$cme["credit_type"]]["board_id"]) {
              		$enroll_html.= $user_selections_indexed[$cme["credit_type"]]["board_id"];
              	} else {
              		if ($saved_board_id) $enroll_html.= $saved_board_id;
              	}
              } else {
              	if ($saved_board_id) $enroll_html.= $saved_board_id;
              }
              $enroll_html.= "\"/></td>";
          	  $enroll_html.= "<td>Date of Birth: <input style=\"width:100px;\" type=\"text\" name=\"dob[".$counter."]\" class=\"bch_cm_datepicker\" id=\"dob_".$counter."\" value=\"";
          	  // get the user's saved dob if there is one
          	  $saved_dob = get_user_meta($current_user->ID, "bch_cm_dob", true);
              if (array_key_exists($cme["credit_type"],$user_selections_indexed) !== false) {
              	if ($user_selections_indexed[$cme["credit_type"]]["dob"]) {
              		$enroll_html.= $user_selections_indexed[$cme["credit_type"]]["dob"];
              	} else {
              		if ($saved_dob) $enroll_html.= $saved_dob;
              	}
              } else {
              	if ($saved_dob) $enroll_html.= $saved_dob;              	
              }
          	  $enroll_html.= "\"/>";
          	  $enroll_html.= "<input type=\"hidden\" name=\"board_name[".$counter."]\" id=\"board_name".$counter."\" value=\"".$credit_type_array[$cme["credit_type"]]."\"/></td>";
            }
          } else $enroll_html.= "<td>&nbsp;</td><td>&nbsp;</td>";
          $enroll_html.= "</tr>";
          $counter++;
        }
        $enroll_html.= "</table></form>";
      }
      $enroll_html.= "<div id=\"next_button_div\"><span style=\"display:none;\" id=\"bch_cme_cm_enrollment_progress\"></span><button style=\"margin-left:12px;\" href=\"javascript:void(0)\" id=\"bch_cme_credit_mananager_next\">Save Credits</button></div>";
    $enroll_html.= "</div>";
    $enroll_html.= "</div>";
    return $enroll_html;

  }

    /**
     * Handle the post of user credit selections for a course
     * author: Stephan Fopeano
     * @return void
    */
    function saveCreditSelection() {
    	global $current_user;
      get_currentuserinfo();

      if (!isset($_GET['enrollment-form-nonce'])) {
    		$retArr = array("result" => "failure", "error" => "The form submission was blocked for security reasons. Please reload the page and try again.");
      	echo json_encode($retArr);
        die();
      }
      if (!wp_verify_nonce($_GET['enrollment-form-nonce'],"enrollment-form-nonce")) {
    		$retArr = array("result" => "failure", "error" => "The form has timed out for security reasons. Please reload the page and try again.");
      	echo json_encode($retArr);
        die();
      }
 
    	if ($current_user->ID == "") {
    		$retArr = array("result" => "failure", "error" => "User is not logged in");
      	echo json_encode($retArr);
    		die();
      }
      
      $course_id = filter_input(INPUT_POST, "course_id", FILTER_SANITIZE_NUMBER_INT);
      if (!$course_id || $course_id == "") {
    		$retArr = array("result" => "failure", "error" => "No course ID was passed");
      	echo json_encode($retArr);
    		die();
      }
      
      $credit_types = $_POST["credit_type"];
      $board_ids = $_POST["board_id"];
      $board_names = $_POST["board_name"];
      $dobs = $_POST["dob"];

      $credit_selected_array = array();
      foreach($credit_types as $index => $credit_type) {
        $this_credit = array();
        $this_credit["credit_type"] = $credit_type;
        if (isset($board_ids[$index])) $this_credit["board_id"] = $board_ids[$index];
        if (isset($board_names[$index])) $this_credit["board_name"] = $board_names[$index];
        if (isset($board_ids[$index]) && isset($board_names[$index])) {
        	// save the user's board id for this board for future recall, but don't over-write with a null
          if ($board_ids[$index] && $board_ids[$index] != "") update_user_meta($current_user->ID, "bch_cm_board_id_".$board_names[$index], $board_ids[$index]);
        }
        if (isset($dobs[$index])) {
        	$this_credit["dob"] = $dobs[$index];
        	// save the user's DOB for future recall, but don't over-write with a null
          if ($dobs[$index] && $dobs[$index] != "") update_user_meta($current_user->ID, 'bch_cm_dob', $dobs[$index]);
        }
        $credit_selected_array[] = $this_credit;
      }
      update_user_meta($current_user->ID, "bch_cm_cme_selections_".$course_id, $credit_selected_array);

      $retArr = array("result" => "success");
      echo json_encode($retArr);
      die();
    }

  /**
    * Allow the user to log in at the point of enrollment to reduce friction in the process
    * author: Stephan Fopeano
    * This is no longer needed since the credit selection is not part of the enrollment flow
    * @return void
  */
  function enrollLogin() {
    global $current_user;
    get_currentuserinfo();

    $credentials = array(
      "user_login" => $_POST["user_login"],
      "user_password" => $_POST["user_password"],
      "remember" => true  
    );
    $new_user = wp_signon($credentials);

    if (is_wp_error($new_user)) {
      $retArr = array("result" => "failure", "error" => $new_user->get_error_message());
      echo json_encode($retArr);
      die();
    }
    wp_set_current_user($new_user->ID);

    $retArr = array("result" => "success", "user_id" => $new_user->ID);
    echo json_encode($retArr);
    die();
  }
  
  /**
    * For the registration form, redirect the user to the course page if they came from a course
    * This will be based on a cookie value
    * author: Stephan Fopeano
    * This is no longer needed since the credit selection is not part of the enrollment flow
    * @return void
  */
  function gravityFormsAfterSubmission($entry, $form) {
  	$form_name = null;
  	foreach($form["fields"] as $field) {
  		if ($field->label == "form_name") $form_name = rgpost("input_".$field->id);
  	}
    //print_r($form);
    if ($form_name == "registration" && $_COOKIE["bch_cme_credit_mananager_course_url"]) {
    	$url = $_COOKIE["bch_cme_credit_mananager_course_url"];
    	// clear the cookie
    	setcookie("bch_cme_credit_mananager_course_url", null);
    	header("Location: ".$url);
    }
  }

  /**
    * Override the template file for the course grid which comes from the learndash course grid plugin
    * This will be based on a cookie value
    * author: Stephan Fopeano
    * @return void
  */
  public function learndash_course_grid_course_list( $filepath, $name, $args, $echo, $return_file_path ) {
	  if ( $name == 'course_list_template') {		
		  if ( $args['shortcode_atts']['course_grid'] == 'false' || 
			  $args['shortcode_atts']['course_grid'] === false || 
			  empty( $args['shortcode_atts']['course_grid'] ) ) {
			  return $filepath;
		  }

		  return apply_filters( 'learndash_course_grid_template', dirname( __FILE__ ) . '/cm_course_list_template.php', $filepath, $name, $args, $return_file_path );
	  }

	  return $filepath;
  }

  public function beforeShopLoop() {
  	//echo "Hello";
	  return "Hello";
  }

  public function filterCourses($query) {
  	global $post;
  	//print_r($post);
    if ($post->post_name == "shop") {
      $meta_query = array(
        'relation' => 'AND',
	      array(
		      'key'     => '_related_course',
		      'value'   => '2709',
		      'compare' => 'LIKE'
	      ),
      );
      $query->set( 'meta_query', $meta_query );
    }
  	//print_r($meta_query);
	  return $query;
  }

  public function generateTranscript() {
  	global $post;
    $user_id = 42;

    // get the filter parameters
    $start_date = filter_input(INPUT_GET, "start_date", FILTER_SANITIZE_STRING);
    $start_date_obj = null;
    if ($start_date) {
    	try {
    		$start_date_obj = new DateTime($start_date);
    	} catch (Exception $e) {
    		// just ignore invalid dates for now, since they are validated on the client side
    	}
    } 
    $end_date = filter_input(INPUT_GET, "end_date", FILTER_SANITIZE_STRING);
    if ($end_date) {
    	try {
    		$end_date_obj = new DateTime($end_date);
    	} catch (Exception $e) {
    		// just ignore invalid dates for now, since they are validated on the client side
    	}
    }
    $credit_type_filter = filter_input(INPUT_GET, "credit_type", FILTER_SANITIZE_STRING);

    require_once('pdf_functions.php');

    $table_header = "<table style=\"font-size:8pt;\" width=\"100%\"><thead>";
    $table_header.= "<tr style=\"font-size:10pt;font-weight:bold;\"><th width=\"10%\">ID</th><th width=\"10%\">Session</th><th width=\"55%\">Activity Name/Date</th><th align=\"right\" width=\"10%\">Credits</th><th align=\"right\" width=\"15%\">Claim Date</th></tr></thead>";
    
    $html.= "<tbody>"; 
       
    // call a helper function to get the table
    // get the list of credit types with their descriptions from the plugin options
    $credit_type_options = get_option("BchCmeCreditManager_Plugin_bch_cm_CreditTypes");
    $credit_type_array = array();
    foreach($credit_type_options as $index => $ct) {
      $credit_type_array[$ct[0]] = $ct[2];
    }

    $credit_array = array();
    $courses_enrolled = learndash_user_get_enrolled_courses($user_id, array(), false );
    foreach($courses_enrolled as $index => $course_id) {
      $course_progress = learndash_user_get_course_progress($user_id, $course_id, 'legacy');
      if ($course_progress["status"] == "completed") {
      	// check the start and end dateDefaults
      	
        // get the credits the user has selected for this course
  	    $meta_key = "bch_cm_cme_selections_".$course_id;
        $user_credits = get_user_meta($user_id, $meta_key, true);

        // get the course completion date
        $meta_key = "course_completed_".$course_id;
        $course_completed_date = get_user_meta($user_id, $meta_key, true);
        $course_completed_obj = new DateTime();
        $course_completed_obj->setTimestamp($course_completed_date);

        // check the date filters
        if ($start_date_obj) {
        	if ($course_completed_obj->format("U") < $start_date_obj->format("U")) continue;
        }
        if ($end_date_obj) {
        	if ($course_completed_obj->format("U") > $end_date_obj->format("U")) continue;
        }

        $course_post = get_post($course_id);

        foreach($user_credits as $user_credit) {
        	if ($credit_type_filter == 0 || $credit_type_filter == $user_credit["credit_type"]) {
            $credit_array[$user_credit["credit_type"]] = array(
              "course_id" => $course_id,
              "credit_description" => $credit_type_array[$user_credit["credit_type"]],
              "course_description" => $course_post->post_title,
              "hours" => get_post_meta($course_id, "bch_cm_cme_credit_hours_".$user_credit["credit_type"], true),
              "completed_date" => $course_completed_obj->format("m-d-Y")
            );
          };
        }
      }
    }

    $page_counter = 0;
    $row_counter = 0;
    $last_credit = null;
    $hours_totals_array = array();
    foreach($credit_array as $credit_id => $credit) {
    	if (!$last_credit) {
    		// add the header but no page break
    		$html.= "<p style=\"font-size:12pt;\">Credit Type: ".$credit["credit_description"]."</p>";
    		$html.= $table_header;
    		$last_credit = $credit_id;
    	} else if ($last_credit != $credit_id) {
        // add a footer row with the total
        $html.= "<tr><td width=\"75%\" align=\"right\" style=\"font-weight:bold;\" colspan=\"3\">Total Hours</td>";
        $html.= "<td width=\"10%\" style=\"font-weight:bold;\" align=\"right\">".$hours_totals_array[$last_credit]."</td>";
        $html.= "<td align=\"right\" width=\"15%\">&nbsp;</td>";
        $html.= "</tr>";

    		// add the header with page break
    		$html.= "<p style=\"font-size:12pt;page-break-before: always;\">Credit Type: ".$credit["credit_description"]."</p>";
    		$html.= $table_header;
    		$last_credit = $credit_id;
    		$page_counter++;
    		$row_counter = 0;
    	}
    	if (!array_key_exists($credit_id,$hours_totals_array)) $hours_totals_array[$credit_id] = (float)$credit["hours"]; else $hours_totals_array[$credit_id]+= (float)$credit["hours"];
      $html.= "<tr><td width=\"10%\">".$credit["course_id"]."</td>";
      $html.= "<td width=\"10%\">&nbsp;</td>";
      $html.= "<td width=\"55%\">".$credit["course_description"]."</td>";
      $html.= "<td align=\"right\" width=\"10%\">".$credit["hours"]."</td>";
      $html.= "<td align=\"right\" width=\"15%\">".$credit["completed_date"]."</td>";
      $html.= "</tr>";
      $row_counter++;
    }
    // add the final footer
    $html.= "<tr><td width=\"75%\" align=\"right\" style=\"font-weight:bold;\" colspan=\"3\">Total Hours</td>";
    $html.= "<td width=\"10%\" style=\"font-weight:bold;\" align=\"right\">".$hours_totals_array[$last_credit]."</td>";
    $html.= "<td align=\"right\" width=\"15%\">&nbsp;</td>";
    $html.= "</tr>";
    $html.= "</tbody></table>";

    $reportTitle = "Transcript";

    $physicianInfo = array(
      "name" => get_user_meta($user_id, "billing_first_name", true)." ".get_user_meta($user_id, "billing_last_name", true),
      "address" => get_user_meta($user_id, "billing_address_1", true),
      "address" => get_user_meta($user_id, "billing_city", true),
      "address" => get_user_meta($user_id, "billing_state", true),
      "address" => get_user_meta($user_id, "billing_zipcode", true),
      "address" => get_user_meta($user_id, "billing_country", true),
    );
    $transcriptPeriod = array();
    if (!$start_date_obj) $transcriptPeriod["start_date"] = "--"; else $transcriptPeriod["start_date"] = $start_date_obj->format("m-d-Y");
    if (!$end_date_obj) $transcriptPeriod["end_date"] = "--"; else $transcriptPeriod["end_date"] = $end_date_obj->format("m-d-Y");

    $pdfString = createPDF($html, $reportTitle, 'browser', "transcript", $physicianInfo, $transcriptPeriod, plugin_dir_path(__FILE__));
	  return true;
  }

  public function addActionsAndFilters() {
    include_once("plugin-update-checker-master/plugin-update-checker.php");
    $myUpdateChecker = Puc_v4_Factory::buildUpdateChecker(
	    'https://www.meliorist.com/plugins/bch_cme_credit_manager/details.json',
	    plugin_dir_path(__FILE__).'bch-cme-credit-manager.php', //Full path to the main plugin file or functions.php.
	    'bch-cme-credit-manager'
    );

    global $post;
    // Add options administration page
    // http://plugin.michael-simpson.com/?page_id=47
    add_action('admin_menu', array(&$this, 'addSettingsSubMenuPage'));

    // Add Actions & Filters
    // http://plugin.michael-simpson.com/?page_id=37
    // add metadata box for cme credit paramaters to apply to the course
    add_action('add_meta_boxes', array(&$this, 'certificateOptions'), 10);
    // update the values in the credit manager metadata box when the user saves the course
    add_action('save_post', array(&$this, 'saveCertificateOptions'), 10);

    add_action('bch_cm_credit_selector', array(&$this, 'creditSelector'), 10);

    //add_action('pre_get_posts', array(&$this, 'filterCourses'), 10, 2 );

    // overrides the template file that's loaded for the course grid, which comes from the learndash course grid plugin
    // set a priority higher than 999999 so that it loads after the learndash course grid plugin
		add_filter( 'learndash_template', array(&$this, 'learndash_course_grid_course_list'), 100000000, 5 );

    // over-ride the default behavior for Gravity Forms so that we can redirect the user to a course
    // page after they complete registration
    add_action( 'gform_after_submission', array(&$this, 'gravityFormsAfterSubmission'), 10, 2 );

    include_once('BchCmeCreditManager_CmeCredit_ShortCode.php');
    $gl = new BchCmeCreditManager_CmeCredit_ShortCode();
    $gl->register('bch_cm_credits');
    
    include_once('BchCmeCreditManager_TranscriptFilters_ShortCode.php');
    $gl = new BchCmeCreditManager_TranscriptFilters_ShortCode();
    $gl->register('bch_cm_transcript_filters');
    
    include_once('BchCmeCreditManager_CourseListFilter_ShortCode.php');
    $clf = new BchCmeCreditManager_CourseListFilter_ShortCode();
    $clf->register('bch_cm_course_list_filter');
 
    // Adding scripts & styles just for the options administration page
    if (strpos($_SERVER['REQUEST_URI'], $this->getSettingsSlug()) !== false) {
      wp_enqueue_script('options_manager_js', plugins_url('/js/options_manager.js', __FILE__));
    }

    // Register short codes
    // http://plugin.michael-simpson.com/?page_id=39

    // Register AJAX hooks
    // http://plugin.michael-simpson.com/?page_id=41
    // saves the form with the user's credit selection
    add_action('wp_ajax_save_credit_selection', array(&$this, 'saveCreditSelection'));

    // creates the user's transcript
    add_action('wp_ajax_generate_transcript', array(&$this, 'generateTranscript'));
    add_action('wp_ajax_nopriv_generate_transcript', array(&$this, 'generateTranscript'));

    // handles the inline login
    add_action('wp_ajax_enroll_login', array(&$this, 'enrollLogin'));
    add_action('wp_ajax_nopriv_enroll_login', array(&$this, 'enrollLogin'));
  }
}
