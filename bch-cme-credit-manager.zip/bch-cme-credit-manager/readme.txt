=== BCH CME Credit Manager ===
Contributors: BCH - Stephan Fopeano
Donate link:
Tags:
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl-3.0.html
Requires at least: 3.5
Tested up to: 3.5
Stable tag: 0.3

Manage CME credits for BCH Courses

== Description ==

Manage CME credits for BCH Courses

== Installation ==


== Frequently Asked Questions ==


== Screenshots ==


== Changelog ==

= 0.1 =
- Initial Revision
