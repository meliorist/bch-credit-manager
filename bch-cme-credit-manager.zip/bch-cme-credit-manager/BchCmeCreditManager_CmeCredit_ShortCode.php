﻿<?php
/**
 * BCH Credit Manager Plugin
 * Author: Stephan Fopeano
 * Class for handling the shortcode that displays the list of groups with filters by group
 *
 */

include_once('BchCmeCreditManager_ShortCodeLoader.php');

class BchCmeCreditManager_CmeCredit_ShortCode extends BchCmeCreditManager_ShortCodeLoader {

	public function __construct() {

  }

  /**
  * @param  $atts shortcode inputs
  * @return string shortcode content
  */
  public function handleShortcode($atts) {
  	global $post;
    $user = wp_get_current_user();
  	$course_id = $_GET["course_id"];

  	// get the credits the user has selected for this course
  	$meta_key = "bch_cm_cme_selections_".$course_id;

  	$user_credits = get_user_meta($user->ID, $meta_key, true);

    // get the list of credit types with their descriptions from the plugin options
    $credit_type_options = get_option("BchCmeCreditManager_Plugin_bch_cm_CreditTypes");
    $credit_type_array = array();
    foreach($credit_type_options as $index => $ct) {
      $credit_type_array[$ct[0]] = $ct[2];
    }

    $cme_credits_string = "";
    if (count($user_credits) > 0) {
      if ($atts["label"]) $cme_credits_string = $atts["label"]." ";
      foreach($user_credits as $credit) {
        $cme_credits_string.= get_post_meta($course_id, "bch_cm_cme_credit_hours_".$credit["credit_type"], true)." hours ".$credit_type_array[$credit["credit_type"]].", ";
      }
      $cme_credits_string = substr($cme_credits_string,0,strlen($cme_credits_string)-2);
    }

    return $cme_credits_string;
  }
}
?>