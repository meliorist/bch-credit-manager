<?php
/**
* BCH CME Credit Manager Helper Functions
*
*
* A PHP class that provides helper functions for the credit manager
*
*
* IMPORTANT NOTE
* 
* 
* LICENCE
* 
*
* @author		Stephan Fopeano
* @version 	001
* @package	
*/

class helperFunctions {

  // Public variables


  /*
  class constructor
  */
  public function __construct() {

  }

  public function getCreditsForTranscript() {



  }

}