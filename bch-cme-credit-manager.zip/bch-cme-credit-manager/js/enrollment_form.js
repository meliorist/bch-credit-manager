﻿jQuery(document).ready(function() {
  jQuery(".bch_cm_datepicker").datepicker();
  jQuery("button").button();

  jQuery("#bch_cme_credit_mananager_enrollment_form").submit(function(event) {
    jQuery("#bch_cme_credit_mananager_next").prop("disabled", "disabled");
  	jQuery("#bch_cme_cm_enrollment_progress").html("<img src=\"" + enrollment_form_object.loading_graphic + "\"/>");
  	jQuery("#bch_cme_cm_enrollment_progress").show();
  	var callUrl = enrollment_form_object.ajax_url + "?action=save_credit_selection";
  	callUrl+= "&enrollment-form-nonce=" + enrollment_form_object.ajax_nonce;
    jQuery.post(callUrl, jQuery("#bch_cme_credit_mananager_enrollment_form").serialize(), function(response) {
      console.log(response);
      if (response.result == "success") {
        jQuery("#bch_cme_credit_mananager_next").prop("disabled", null);
        jQuery("#bch_cme_cm_enrollment_progress").html("Credits saved");
      } else {
        jQuery("#bch_cme_cm_enrollment_progress").html("Error: " + response.error);
      }
    },"json");
    event.preventDefault();
  });
  
  jQuery("#bch_cme_credit_mananager_next").click(function(event) {
  	jQuery("#bch_cme_credit_mananager_enrollment_form").submit();
  });
});