﻿jQuery(document).ready(function() {
  jQuery("#bch_cm_add_rows").click(function(event) {
	  var credit_types = jQuery.parseJSON(bch_cm_credit_type_options);
    var row_count = jQuery("#bch_cm_credit_table tbody tr").length;
	  var table_html = "<tr id=\"cme_options_row_" + row_count + "\">";
	  table_html+= "<td><select id=\"credit_type_" + row_count + "\" name=\"cme_options[" + row_count + "][credit_type]\">";
	  table_html+= "<option value=\"\">Please select</option>";
	  jQuery.each(credit_types, function(index, credit_type) {
	    table_html+= "<option value=\"" + index + "\">" + credit_type + "</option>";	
    });
	  table_html+= "</select></td>";
	  table_html+= "<td><input type=\"text\" name=\"cme_options[" + row_count + "][credit_hours]\" id=\"credit_hours_" + row_count + "\" value=\"\"/></td></tr>";
	
	  jQuery("#bch_cm_credit_table tbody").append(table_html);
  });

  jQuery(".bch-cm-remove-row").click(function(event, elem) {
	  jQuery(this).parent().parent().remove();
  });
});