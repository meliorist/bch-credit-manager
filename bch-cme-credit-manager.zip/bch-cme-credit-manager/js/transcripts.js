jQuery(document).ready(function() {
  jQuery("#bch_transcript_download_link").click(function(event, elem){
    event.preventDefault();
    var url = "/wp-admin/admin-ajax.php?action=generate_transcript"; 
    url+= "&start_date=" + jQuery("#bch_transcript_download_start_date").val();
    url+= "&end_date=" + jQuery("#bch_transcript_download_end_date").val();
    url+= "&credit_type=" + jQuery("#bch_transcript_download_credit_type").val();

    window.open(url,"_blank");
  });
});