﻿jQuery(document).ready(function() {
  jQuery(".bch_cm_add_new_option").click(function(event) {
    var row_count = jQuery("#bch_cm_options_table tr").length;
	  var table_html = "<tr id=\"bch_cm_options_row_" + row_count + "\">";
	  table_html+= "<td><input type=\"text\" style=\"width:40px;\" name=\"" + jQuery("#aOptionKey").val() + "[" + row_count + "][0]\" id=\"" + jQuery("#aOptionKey").val() + "_0_" + row_count + "\" value=\"\"/>";
	  table_html+= "<td><input type=\"checkbox\" name=\"" + jQuery("#aOptionKey").val() + "[" + row_count + "][1]\" id=\"" + jQuery("#aOptionKey").val() + "_1_" + row_count + "\" value=\"1\" checked=\"checked\"/>";
	  table_html+= "<td><input type=\"text\" style=\"width:400px;\" name=\"" + jQuery("#aOptionKey").val() + "[" + row_count + "][2]\" id=\"" + jQuery("#aOptionKey").val() + "_2_" + row_count + "\" value=\"\"/></td>";
	  table_html+= "<td><input type=\"text\" name=\"" + jQuery("#aOptionKey").val() + "[" + row_count + "][3]\" id=\"" + jQuery("#aOptionKey").val() + "_3_" + row_count + "\" value=\"\"/></td>";
	  table_html+= "<td><input type=\"text\" name=\"" + jQuery("#aOptionKey").val() + "[" + row_count + "][4]\" id=\"" + jQuery("#aOptionKey").val() + "_4_" + row_count + "\" value=\"\"/></td>";
	  table_html+= "<td><a href=\"javascript:void(0);\" class=\"bch_cm_remove_option\" id=\"bch_cm_remove_" + row_count + "\">Remove</a></td></tr>";	
	  jQuery("#bch_cm_options_table").append(table_html);
  });

  jQuery(".bch_cm_remove_option").click(function(event, elem) {
	  jQuery(this).parent().parent().remove();
  });
});