<?php
/**
 * BCH Credit Manager Plugin
 * Author: Stephan Fopeano
 * Class for handling the shortcode that displays the credit-related filters for the course list
 *
 */

include_once('BchCmeCreditManager_ShortCodeScriptLoader.php');

class BchCmeCreditManager_CourseListFilter_ShortCode extends BchCmeCreditManager_ShortCodeScriptLoader {

  static $addedAlready = false;

	public function __construct() {

  }

  /**
  * @param  $atts shortcode inputs
  * @return string shortcode content
  */
  public function handleShortcode($atts) {
  	global $post;

    // register a custom query var for the querystring
    function myplugin_query_vars( $qvars ) {
      $qvars[] = 'bch_cm_credit_type';
      return $qvars;
    }
    add_filter('query_vars', 'myplugin_query_vars');

    $credit_type = filter_input(INPUT_GET, "bch_cm_credit_type", FILTER_SANITIZE_STRING);

add_filter(
    'learndash_ld_course_list_query_args',
    function( $filter, $atts ) {
        // May add any custom logic using $filter, $atts.
        $value = "Physician";
        $filter["meta_query"] = array(
          array(
            "key" => "bch_cm_cme_options",
            "compare" => "EXISTS"
          )
        );
//print_r($filter);
//exit; 
        // Always return $filter.
        return $filter;
    },
    10,
    2
);


  	
    $filter_html = "Credit type: ";
    $filter_html.= "<form method=\"GET\" action=\"\"/>";
    $filter_html.= "<select name=\"bch_cm_credit_type\" id=\"bch_cm_credit_type_select\">";
    $filter_html.= "<option value=\"option_1\">Option 1</option>";
    $filter_html.= "</select>";
    $filter_html.= "<input type=\"submit\" value=\"Search\"/>";
    $filter_html.= "</form>";

    return $filter_html;
  }

  public function addScript() {
    if (!self::$addedAlready) {
      self::$addedAlready = true;
      //wp_enqueue_style("jquery-ui-css", plugin_dir_url( __FILE__ )."js/jquery-ui-1.12.1/jquery-ui.min.css"); 
      //wp_enqueue_style("full-calendar-css", "https://cdn.jsdelivr.net/npm/fullcalendar@5.5.1/main.css");

      wp_enqueue_script('jquery');

      // The second parameter ('ajax_url') will be used in the javascript code.
      //wp_localize_script('bf_pickup', 'bf_pickup_object', array(
      //  'ajax_url' => admin_url( 'admin-ajax.php' ),
      //  'ajax_nonce' => wp_create_nonce('bf_pickup-nonce') 
      //)); 
    }
  }
}