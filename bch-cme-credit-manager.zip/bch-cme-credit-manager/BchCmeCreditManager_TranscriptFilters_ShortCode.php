<?php
/**
 * BCH Credit Manager Plugin
 * Author: Stephan Fopeano
 * Class for handling the shortcode that displays filters for the transcript option and prints the transcript
 *
 */

include_once('BchCmeCreditManager_ShortCodeScriptLoader.php');

class BchCmeCreditManager_TranscriptFilters_ShortCode extends BchCmeCreditManager_ShortCodeScriptLoader {

  static $addedAlready = false;

	public function __construct() {

  }

  /**
  * @param  $atts shortcode inputs
  * @return string shortcode content
  */
  public function handleShortcode($atts) {
  	global $post;

    $credit_type_options = get_option("BchCmeCreditManager_Plugin_bch_cm_CreditTypes");
    $credit_type_array = array();
    foreach($credit_type_options as $index => $ct) {
      $credit_type_array[$ct[0]] = $ct[2];
    }
  	
  	$html = "<div style=\"width:100%;\">";
  	$html.= "<div style=\"float:left;width:30%;\">Filter by date";
    $html.= "<div>Start Date: <input type=\"text\" name=\"bch_transcript_download_start_date\" id=\"bch_transcript_download_start_date\" value=\"\"/></div>";
    $html.= "<div>End Date: <input type=\"text\" name=\"bch_transcript_download_end_date\" id=\"bch_transcript_download_end_date\" value=\"\"/></div>";
  	$html.= "</div>";
  	$html.= "<div style=\"float:left;width:30%;\">Filter by Credit Types";
    $html.= "<div><select name=\"bch_transcript_download_credit_type\" id=\"bch_transcript_download_credit_type\">";
    $html.= "<option value=\"0\">All Credit Types</option>";
    foreach($credit_type_array as $credit_type_id => $credit_type_desc) {
  	  $html.= "<option value=\"".$credit_type_id."\">".$credit_type_desc."</option>";
  	}
    $html.= "</select>";    
    $html.= "</div>";
  	$html.= "</div>";
  	$html.= "<div style=\"float:left;width:30%;\"><a id=\"bch_transcript_download_link\" target=\"_blank\">Download Transcript</a>";
  	$html.= "<br/>Email Transcript";
  	$html.= "</div>";
  	$html.= "</div>";

    return $html;
  }

  public function addScript() {
    if (!self::$addedAlready) {
      self::$addedAlready = true;
      //wp_enqueue_style("jquery-ui-css", plugin_dir_url( __FILE__ )."js/jquery-ui-1.12.1/jquery-ui.min.css"); 
      //wp_enqueue_style("full-calendar-css", "https://cdn.jsdelivr.net/npm/fullcalendar@5.5.1/main.css");

      wp_enqueue_script('jquery');
      wp_enqueue_script("transcript-filters-js", plugin_dir_url( __FILE__ )."js/transcripts.js");
      wp_enqueue_script("moment-js", plugin_dir_url( __FILE__ )."js/moment.js");

      // The second parameter ('ajax_url') will be used in the javascript code.
      //wp_localize_script('bf_pickup', 'bf_pickup_object', array(
      //  'ajax_url' => admin_url( 'admin-ajax.php' ),
      //  'ajax_nonce' => wp_create_nonce('bf_pickup-nonce') 
      //)); 
    }
  }
}
?>